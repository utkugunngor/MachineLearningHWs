To use the functions in different files, just import the files with filename. Run command for Windows:

	"python filename.py"


- There are 4 different svm files for each of the 4 tasks.
- draw.py(given in the recitation link) is imported in some files.