I have not created any additional file to the given directory. All related functions are implemented in hmm.py and nb.py.

nb_data is used for experiments in nb.py. I am not submitting those data since you have it.

Run command for Windows:
	python filename.py